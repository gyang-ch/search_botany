# Exact-neighbour and model-comparison stage

This bundle consumes the aligned OpenCLIP and DINOv2 outputs created by the
illustration embedding pipeline.

- `build_exact_neighbors.py`: exhaustive float32 GPU cosine search, resumable,
  with optional CPU `IndexFlatIP` serialisation.
- `compare_neighbor_models.py`: overlap, Jaccard, same-book, same-source, and
  cross-book comparison metrics without comparing score magnitudes across
  embedding spaces.
- `make_retrieval_contact_sheets.py`: curated side-by-side retrieval sheets.

The default stored depth is 200 neighbours so that analysis through `k=100`
can still form cross-book subsets when some early neighbours are from the same
book.

