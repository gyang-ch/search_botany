#!/usr/bin/env python3
"""Make side-by-side OpenCLIP and DINOv2 retrieval contact sheets."""

from __future__ import annotations

import argparse
import math
from pathlib import Path

import numpy as np
import pandas as pd
from PIL import Image, ImageDraw, ImageFont, ImageOps


def arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--crop-root", type=Path, required=True)
    parser.add_argument("--crop-manifest", type=Path, required=True)
    parser.add_argument("--comparison", type=Path, required=True)
    parser.add_argument("--openclip-neighbours", type=Path, required=True)
    parser.add_argument("--dinov2-neighbours", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--neighbours", type=int, default=8)
    parser.add_argument("--per-category", type=int, default=4)
    parser.add_argument("--seed", type=int, default=20260826)
    return parser.parse_args()


def load_image(path: Path, size: tuple[int, int]) -> Image.Image:
    with Image.open(path) as opened:
        image = opened.convert("RGB")
    return ImageOps.contain(image, size, method=Image.Resampling.LANCZOS)


def paste_tile(
    canvas: Image.Image,
    draw: ImageDraw.ImageDraw,
    manifest: pd.DataFrame,
    crop_root: Path,
    row_index: int,
    x: int,
    y: int,
    width: int,
    height: int,
    label: str,
) -> None:
    record = manifest.iloc[row_index]
    image = load_image(crop_root / str(record["crop_relative_path"]), (width - 12, height - 48))
    image_x = x + (width - image.width) // 2
    image_y = y + 5
    canvas.paste(image, (image_x, image_y))
    draw.rectangle((x, y, x + width - 1, y + height - 1), outline="#555b66", width=1)
    text = f"{label}\n{record['source']} · {str(record['item_id'])[:18]}"
    draw.multiline_text((x + 6, y + height - 38), text, fill="#ecedf0", spacing=2)


def make_sheet(
    query: int,
    manifest: pd.DataFrame,
    crop_root: Path,
    clip_indices: np.ndarray,
    clip_scores: np.ndarray,
    dino_indices: np.ndarray,
    dino_scores: np.ndarray,
    output_path: Path,
    neighbour_count: int,
    reason: str,
) -> None:
    query_width = 300
    tile_width, tile_height = 190, 235
    margin, header = 18, 64
    canvas_width = query_width + margin * 3 + neighbour_count * tile_width
    canvas_height = header + tile_height * 2 + margin * 3
    canvas = Image.new("RGB", (canvas_width, canvas_height), "#15171b")
    draw = ImageDraw.Draw(canvas)
    query_record = manifest.iloc[query]
    title = (
        f"Query row {query} · {query_record['crop_id']} · {query_record['source']} · "
        f"selection: {reason}"
    )
    draw.text((margin, 18), title, fill="white")
    query_y = header + (tile_height * 2 + margin - 320) // 2
    paste_tile(canvas, draw, manifest, crop_root, query, margin, query_y, query_width, 320, "QUERY")
    grid_x = query_width + margin * 2
    draw.text((grid_x, header - 18), "OpenCLIP nearest neighbours", fill="#67d5ff")
    draw.text((grid_x, header + tile_height + margin - 18), "DINOv2 nearest neighbours", fill="#ff9d67")
    for rank in range(neighbour_count):
        x = grid_x + rank * tile_width
        clip_row = int(clip_indices[query, rank])
        dino_row = int(dino_indices[query, rank])
        paste_tile(
            canvas, draw, manifest, crop_root, clip_row, x, header,
            tile_width, tile_height, f"#{rank + 1}  {float(clip_scores[query, rank]):.4f}",
        )
        paste_tile(
            canvas, draw, manifest, crop_root, dino_row, x,
            header + tile_height + margin, tile_width, tile_height,
            f"#{rank + 1}  {float(dino_scores[query, rank]):.4f}",
        )
    output_path.parent.mkdir(parents=True, exist_ok=True)
    canvas.save(output_path, quality=90, optimize=True)


def choose_queries(comparison: pd.DataFrame, per_category: int, seed: int) -> pd.DataFrame:
    selections: list[dict] = []

    def add(rows: pd.DataFrame, reason: str) -> None:
        for row_index in rows["row_index"].astype(int):
            selections.append({"row_index": row_index, "selection_reason": reason})

    for offset, (source, group) in enumerate(sorted(comparison.groupby("source")), 1):
        count = min(per_category, len(group))
        add(group.sample(n=count, random_state=seed + offset), f"random_source_{source}")
    overlap_column = "overlap_fraction_at_20"
    add(comparison.nsmallest(per_category * 2, overlap_column), "lowest_overlap_at_20")
    add(comparison.nlargest(per_category * 2, overlap_column), "highest_overlap_at_20")
    add(comparison.nsmallest(per_category, "confidence"), "lowest_yolo_confidence")
    add(comparison.nsmallest(per_category, "aspect_ratio"), "tallest_aspect_ratio")
    add(comparison.nlargest(per_category, "aspect_ratio"), "widest_aspect_ratio")
    selected = pd.DataFrame(selections).drop_duplicates("row_index", keep="first")
    return selected.sort_values(["selection_reason", "row_index"]).reset_index(drop=True)


def main() -> int:
    args = arguments()
    crop_root = args.crop_root.resolve()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    manifest = pd.read_parquet(args.crop_manifest).sort_values("row_index").reset_index(drop=True)
    comparison = pd.read_parquet(args.comparison).sort_values("row_index").reset_index(drop=True)
    clip_dir = args.openclip_neighbours.resolve()
    dino_dir = args.dinov2_neighbours.resolve()
    clip_indices = np.load(clip_dir / "neighbour_indices.npy", mmap_mode="r")
    clip_scores = np.load(clip_dir / "neighbour_scores.npy", mmap_mode="r")
    dino_indices = np.load(dino_dir / "neighbour_indices.npy", mmap_mode="r")
    dino_scores = np.load(dino_dir / "neighbour_scores.npy", mmap_mode="r")
    if args.neighbours > clip_indices.shape[1] or args.neighbours > dino_indices.shape[1]:
        raise SystemExit("Requested display-neighbour count exceeds stored neighbours")
    if len(manifest) != len(comparison) or len(manifest) != clip_indices.shape[0]:
        raise SystemExit("Manifest, comparison, and neighbour row counts differ")

    selected = choose_queries(comparison, args.per_category, args.seed)
    selected = selected.merge(
        manifest[["row_index", "crop_id", "source", "item_id", "crop_relative_path"]],
        on="row_index", how="left", validate="one_to_one",
    )
    selected.to_csv(output_dir / "selected_queries.csv", index=False)
    for position, record in selected.iterrows():
        query = int(record["row_index"])
        safe_reason = "".join(character if character.isalnum() or character in "-_" else "_" for character in record["selection_reason"])
        destination = output_dir / "sheets" / f"{position:03d}__row_{query:06d}__{safe_reason}.jpg"
        make_sheet(
            query, manifest, crop_root, clip_indices, clip_scores,
            dino_indices, dino_scores, destination,
            args.neighbours, str(record["selection_reason"]),
        )
        print(f"Wrote {destination}")
    print(f"Created {len(selected)} retrieval comparison sheets in {output_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
