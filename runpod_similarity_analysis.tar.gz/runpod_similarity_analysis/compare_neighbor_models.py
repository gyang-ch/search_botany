#!/usr/bin/env python3
"""Compare OpenCLIP and DINOv2 neighbour identities and rank behaviour."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd


def arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--openclip-neighbours", type=Path, required=True)
    parser.add_argument("--dinov2-neighbours", type=Path, required=True)
    parser.add_argument("--embedding-manifest", type=Path, required=True)
    parser.add_argument("--crop-manifest", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--ks", default="5,10,20,50,100")
    return parser.parse_args()


def filtered(neighbours: np.ndarray, item_ids: np.ndarray, query_item: str, k: int) -> np.ndarray:
    selected = [int(index) for index in neighbours if item_ids[int(index)] != query_item]
    return np.asarray(selected[:k], dtype=np.int32)


def overlap_values(first: np.ndarray, second: np.ndarray, denominator: int) -> tuple[int, float, float]:
    overlap = len(set(first.tolist()) & set(second.tolist()))
    fraction = overlap / denominator if denominator else float("nan")
    union = len(set(first.tolist()) | set(second.tolist()))
    jaccard = overlap / union if union else float("nan")
    return overlap, fraction, jaccard


def main() -> int:
    args = arguments()
    ks = sorted({int(value) for value in args.ks.split(",") if value.strip()})
    clip_dir = args.openclip_neighbours.resolve()
    dino_dir = args.dinov2_neighbours.resolve()
    clip_indices = np.load(clip_dir / "neighbour_indices.npy", mmap_mode="r")
    dino_indices = np.load(dino_dir / "neighbour_indices.npy", mmap_mode="r")
    clip_scores = np.load(clip_dir / "neighbour_scores.npy", mmap_mode="r")
    dino_scores = np.load(dino_dir / "neighbour_scores.npy", mmap_mode="r")
    if clip_indices.shape != dino_indices.shape or clip_scores.shape != clip_indices.shape or dino_scores.shape != dino_indices.shape:
        print("ERROR: neighbour array shapes differ", file=sys.stderr)
        return 2
    if max(ks) > clip_indices.shape[1]:
        print("ERROR: requested k exceeds stored neighbour count", file=sys.stderr)
        return 2

    embedding_manifest = pd.read_parquet(args.embedding_manifest).sort_values("row_index").reset_index(drop=True)
    crop_manifest = pd.read_parquet(args.crop_manifest).sort_values("row_index").reset_index(drop=True)
    if len(embedding_manifest) != clip_indices.shape[0] or len(crop_manifest) != clip_indices.shape[0]:
        print("ERROR: manifest row count does not match neighbour arrays", file=sys.stderr)
        return 2
    if not embedding_manifest["crop_id"].equals(crop_manifest["crop_id"]):
        print("ERROR: embedding and crop manifests are not aligned", file=sys.stderr)
        return 2

    item_ids = embedding_manifest["item_id"].fillna("").astype(str).to_numpy()
    sources = embedding_manifest["source"].fillna("").astype(str).to_numpy()
    records = []
    for query in range(len(embedding_manifest)):
        record = {
            "row_index": query,
            "crop_id": embedding_manifest.iloc[query]["crop_id"],
            "source": sources[query],
            "item_id": item_ids[query],
            "confidence": float(embedding_manifest.iloc[query]["confidence"]),
            "crop_width": int(crop_manifest.iloc[query]["crop_width"]),
            "crop_height": int(crop_manifest.iloc[query]["crop_height"]),
            "aspect_ratio": float(crop_manifest.iloc[query]["crop_width"] / max(1, crop_manifest.iloc[query]["crop_height"])),
        }
        for k in ks:
            clip_k = np.asarray(clip_indices[query, :k])
            dino_k = np.asarray(dino_indices[query, :k])
            overlap, fraction, jaccard = overlap_values(clip_k, dino_k, k)
            record[f"overlap_count_at_{k}"] = overlap
            record[f"overlap_fraction_at_{k}"] = fraction
            record[f"jaccard_at_{k}"] = jaccard
            record[f"openclip_same_book_fraction_at_{k}"] = float(np.mean(item_ids[clip_k] == item_ids[query]))
            record[f"dinov2_same_book_fraction_at_{k}"] = float(np.mean(item_ids[dino_k] == item_ids[query]))
            record[f"openclip_same_source_fraction_at_{k}"] = float(np.mean(sources[clip_k] == sources[query]))
            record[f"dinov2_same_source_fraction_at_{k}"] = float(np.mean(sources[dino_k] == sources[query]))

            clip_cross = filtered(clip_indices[query], item_ids, item_ids[query], k)
            dino_cross = filtered(dino_indices[query], item_ids, item_ids[query], k)
            available = min(len(clip_cross), len(dino_cross), k)
            if available:
                cross_overlap, cross_fraction, cross_jaccard = overlap_values(
                    clip_cross[:available], dino_cross[:available], available
                )
            else:
                cross_overlap, cross_fraction, cross_jaccard = 0, float("nan"), float("nan")
            record[f"cross_book_available_at_{k}"] = available
            record[f"cross_book_overlap_count_at_{k}"] = cross_overlap
            record[f"cross_book_overlap_fraction_at_{k}"] = cross_fraction
            record[f"cross_book_jaccard_at_{k}"] = cross_jaccard
        records.append(record)
        if (query + 1) % 5000 == 0:
            print(f"Compared {query + 1:,}/{len(embedding_manifest):,}", flush=True)

    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    frame = pd.DataFrame(records).sort_values("row_index")
    frame.to_parquet(output_dir / "per_query_comparison.parquet", index=False)
    frame.to_csv(output_dir / "per_query_comparison.csv", index=False)
    metric_columns = [column for column in frame.columns if "_at_" in column]
    aggregate = {}
    for column in metric_columns:
        values = frame[column].dropna()
        aggregate[column] = {
            "mean": float(values.mean()),
            "median": float(values.median()),
            "q25": float(values.quantile(0.25)),
            "q75": float(values.quantile(0.75)),
        }
    source_summary = frame.groupby("source")[metric_columns].mean(numeric_only=True).reset_index()
    source_summary.to_parquet(output_dir / "comparison_by_source.parquet", index=False)
    source_summary.to_csv(output_dir / "comparison_by_source.csv", index=False)
    summary = {
        "status": "completed",
        "query_count": len(frame),
        "stored_neighbours_per_model": int(clip_indices.shape[1]),
        "ks": ks,
        "important_note": "Cosine magnitudes are not compared across models; metrics use neighbour identities and ranks.",
        "aggregate_metrics": aggregate,
    }
    (output_dir / "comparison_summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: value for key, value in summary.items() if key != "aggregate_metrics"}, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())

