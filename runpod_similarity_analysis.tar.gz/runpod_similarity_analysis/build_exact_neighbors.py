#!/usr/bin/env python3
"""Build resumable exact cosine-neighbour arrays with PyTorch on GPU.

The source embeddings are already L2-normalised, so their matrix inner
product is cosine similarity. A serialisable CPU FAISS IndexFlatIP can also
be written for later interactive search; FAISS is not used for the GPU batch
search, avoiding CUDA-package compatibility problems on RunPod.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import time
from pathlib import Path
from typing import Any

import numpy as np
import torch


def arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--embedding-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--top-k", type=int, default=200)
    parser.add_argument("--query-batch-size", type=int, default=256)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--write-faiss-index", action="store_true")
    parser.add_argument("--restart", action="store_true")
    return parser.parse_args()


def atomic_json(path: Path, value: dict[str, Any]) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")
    os.replace(temporary, path)


def write_faiss_index(embeddings: np.ndarray, destination: Path, batch_size: int = 8192) -> None:
    try:
        import faiss
    except ImportError as exc:
        raise RuntimeError("faiss-cpu is required for --write-faiss-index") from exc
    index = faiss.IndexFlatIP(int(embeddings.shape[1]))
    for start in range(0, len(embeddings), batch_size):
        stop = min(start + batch_size, len(embeddings))
        index.add(np.ascontiguousarray(embeddings[start:stop], dtype=np.float32))
    faiss.write_index(index, str(destination))


def main() -> int:
    args = arguments()
    embedding_dir = args.embedding_dir.resolve()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    progress_path = output_dir / "progress.json"
    indices_path = output_dir / "neighbour_indices.npy"
    scores_path = output_dir / "neighbour_scores.npy"
    source_path = embedding_dir / "embeddings.npy"
    source_metadata_path = embedding_dir / "embedding_metadata.json"

    if args.device.startswith("cuda") and not torch.cuda.is_available():
        print("ERROR: CUDA requested but unavailable", file=sys.stderr)
        return 2
    # Copy-on-write mapping is writable from NumPy/PyTorch's perspective but
    # cannot modify embeddings.npy on disk.
    source = np.load(source_path, mmap_mode="c")
    if source.dtype != np.float32 or source.ndim != 2:
        print(f"ERROR: expected a 2-D float32 embedding array, got {source.shape} {source.dtype}", file=sys.stderr)
        return 2
    row_count, dimension = source.shape
    if not 1 <= args.top_k < row_count:
        print("ERROR: top-k must be between 1 and row_count-1", file=sys.stderr)
        return 2
    norms = np.linalg.norm(source, axis=1)
    if not np.isfinite(source).all() or not np.allclose(norms, 1.0, atol=2e-4):
        print("ERROR: source embeddings are non-finite or not L2-normalised", file=sys.stderr)
        return 2
    source_metadata = json.loads(source_metadata_path.read_text(encoding="utf-8"))
    identity = {
        "embedding_sha256": source_metadata.get("embedding_file_sha256"),
        "manifest_sha256": source_metadata.get("source_crop_manifest_sha256"),
        "shape": [row_count, dimension],
        "top_k": args.top_k,
    }

    if args.restart:
        for path in (progress_path, indices_path, scores_path, output_dir / "index.faiss"):
            path.unlink(missing_ok=True)
    start_index = 0
    if progress_path.exists():
        progress = json.loads(progress_path.read_text(encoding="utf-8"))
        if progress.get("identity") != identity:
            print("ERROR: existing output belongs to another embedding/top-k configuration; pass --restart", file=sys.stderr)
            return 2
        if progress.get("status") == "completed":
            print(f"Neighbour generation already completed: {output_dir}")
            return 0
        start_index = int(progress.get("next_index", 0))

    if indices_path.exists() and scores_path.exists():
        neighbour_indices = np.lib.format.open_memmap(indices_path, mode="r+")
        neighbour_scores = np.lib.format.open_memmap(scores_path, mode="r+")
        if neighbour_indices.shape != (row_count, args.top_k) or neighbour_scores.shape != (row_count, args.top_k):
            print("ERROR: existing neighbour arrays have unexpected shapes; pass --restart", file=sys.stderr)
            return 2
    else:
        neighbour_indices = np.lib.format.open_memmap(
            indices_path, mode="w+", dtype=np.int32, shape=(row_count, args.top_k)
        )
        neighbour_scores = np.lib.format.open_memmap(
            scores_path, mode="w+", dtype=np.float32, shape=(row_count, args.top_k)
        )

    device = torch.device(args.device)
    # Disable TF32 so results use full float32 matmul rather than reduced
    # mantissa precision. The operation remains exhaustive and deterministic.
    if device.type == "cuda":
        torch.backends.cuda.matmul.allow_tf32 = False
    database = torch.from_numpy(np.asarray(source)).to(device=device, dtype=torch.float32)
    started = time.time()
    next_index = start_index
    atomic_json(progress_path, {
        "status": "running", "identity": identity, "next_index": start_index,
        "row_count": row_count,
    })
    try:
        with torch.inference_mode():
            for start in range(start_index, row_count, args.query_batch_size):
                stop = min(start + args.query_batch_size, row_count)
                query = database[start:stop]
                similarities = query @ database.T
                local_rows = torch.arange(stop - start, device=device)
                global_rows = torch.arange(start, stop, device=device)
                similarities[local_rows, global_rows] = -torch.inf
                scores, indices = torch.topk(
                    similarities, k=args.top_k, dim=1, largest=True, sorted=True
                )
                neighbour_indices[start:stop] = indices.cpu().numpy().astype(np.int32, copy=False)
                neighbour_scores[start:stop] = scores.cpu().numpy().astype(np.float32, copy=False)
                next_index = stop
                neighbour_indices.flush()
                neighbour_scores.flush()
                atomic_json(progress_path, {
                    "status": "running", "identity": identity,
                    "next_index": next_index, "row_count": row_count,
                    "elapsed_seconds": round(time.time() - started, 2),
                })
                print(f"Exact neighbours: {next_index:,}/{row_count:,}", flush=True)
    except KeyboardInterrupt:
        neighbour_indices.flush()
        neighbour_scores.flush()
        atomic_json(progress_path, {
            "status": "interrupted", "identity": identity,
            "next_index": next_index, "row_count": row_count,
        })
        print("Interrupted safely; rerun the same command to resume.", file=sys.stderr)
        return 130

    if np.any(neighbour_indices == np.arange(row_count, dtype=np.int32)[:, None]):
        print("ERROR: self-neighbours remain in output", file=sys.stderr)
        return 2
    if not np.isfinite(neighbour_scores).all():
        print("ERROR: non-finite neighbour scores", file=sys.stderr)
        return 2
    if np.any(np.diff(neighbour_scores, axis=1) > 1e-6):
        print("ERROR: neighbour scores are not descending", file=sys.stderr)
        return 2

    faiss_path = output_dir / "index.faiss"
    if args.write_faiss_index and not faiss_path.exists():
        print("Writing CPU FAISS IndexFlatIP...", flush=True)
        write_faiss_index(source, faiss_path)
    metadata = {
        **identity,
        "status": "completed",
        "method": "exhaustive PyTorch float32 matrix inner product",
        "metric": "cosine_similarity_via_inner_product_of_l2_normalized_vectors",
        "self_neighbour_removed": True,
        "device": str(device),
        "gpu_name": torch.cuda.get_device_name(device) if device.type == "cuda" else None,
        "query_batch_size": args.query_batch_size,
        "elapsed_seconds_this_invocation": round(time.time() - started, 2),
        "faiss_index_written": faiss_path.exists(),
        "faiss_index_type": "IndexFlatIP" if faiss_path.exists() else None,
    }
    (output_dir / "neighbour_metadata.json").write_text(json.dumps(metadata, indent=2) + "\n", encoding="utf-8")
    atomic_json(progress_path, {
        "status": "completed", "identity": identity,
        "next_index": row_count, "row_count": row_count,
    })
    print(json.dumps(metadata, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
