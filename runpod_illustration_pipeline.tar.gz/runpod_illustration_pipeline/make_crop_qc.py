#!/usr/bin/env python3
"""Create deterministic contact sheets for crop quality control."""

from __future__ import annotations

import argparse
import math
from pathlib import Path

import pandas as pd
from PIL import Image, ImageDraw, ImageFont, ImageOps


def arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--crop-root", type=Path, required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--per-sheet", type=int, default=48)
    parser.add_argument("--seed", type=int, default=20260826)
    return parser.parse_args()


def make_sheet(frame: pd.DataFrame, crop_root: Path, destination: Path, title: str) -> None:
    cell_width, cell_height = 240, 280
    columns = 6
    rows = max(1, math.ceil(len(frame) / columns))
    sheet = Image.new("RGB", (columns * cell_width, 44 + rows * cell_height), "#17191d")
    draw = ImageDraw.Draw(sheet)
    font = ImageFont.load_default()
    draw.text((12, 14), title, fill="white", font=font)
    for position, (_, record) in enumerate(frame.iterrows()):
        column, row = position % columns, position // columns
        x, y = column * cell_width, 44 + row * cell_height
        path = crop_root / str(record["crop_relative_path"])
        with Image.open(path) as opened:
            image = opened.convert("RGB")
        fitted = ImageOps.contain(image, (cell_width - 16, cell_height - 58))
        image_x = x + (cell_width - fitted.width) // 2
        image_y = y + 6
        sheet.paste(fitted, (image_x, image_y))
        label = f"{record['source']}  conf={float(record['confidence']):.3f}\n{record['crop_id']}"
        draw.multiline_text((x + 8, y + cell_height - 46), label, fill="#e7e9ec", font=font, spacing=2)
    destination.parent.mkdir(parents=True, exist_ok=True)
    sheet.save(destination, quality=90)


def sampled(frame: pd.DataFrame, count: int, seed: int) -> pd.DataFrame:
    return frame if len(frame) <= count else frame.sample(n=count, random_state=seed).sort_values("row_index")


def main() -> int:
    args = arguments()
    frame = pd.read_parquet(args.manifest)
    frame = frame[frame["status"] == "ok"].copy()
    frame["area"] = frame["crop_file_width"] * frame["crop_file_height"]
    frame["aspect_ratio"] = frame["crop_file_width"] / frame["crop_file_height"].clip(lower=1)
    output_dir = args.output_dir.resolve()
    crop_root = args.crop_root.resolve()
    make_sheet(sampled(frame, args.per_sheet, args.seed), crop_root, output_dir / "random_all.jpg", "Random crops across all sources")
    for offset, (source, group) in enumerate(sorted(frame.groupby("source")), 1):
        make_sheet(sampled(group, args.per_sheet, args.seed + offset), crop_root, output_dir / f"source_{source}.jpg", f"Source: {source}")
    make_sheet(frame.nsmallest(args.per_sheet, "area"), crop_root, output_dir / "smallest_crops.jpg", "Smallest crops")
    make_sheet(frame.nsmallest(args.per_sheet, "confidence"), crop_root, output_dir / "lowest_confidence.jpg", "Lowest-confidence illustration detections")
    extreme = pd.concat([
        frame.nsmallest(args.per_sheet // 2, "aspect_ratio"),
        frame.nlargest(args.per_sheet // 2, "aspect_ratio"),
    ]).drop_duplicates("crop_id")
    make_sheet(extreme, crop_root, output_dir / "extreme_aspect_ratios.jpg", "Extreme aspect ratios")
    print(f"QC contact sheets written to {output_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

