# Frozen illustration dataset and embedding pipeline

These scripts implement a log-defined, versioned pipeline:

1. `build_crop_manifest.py` validates frozen logs, source images, and boxes.
2. `crop_illustrations.py` creates exact YOLO crops from unannotated pages.
3. `make_crop_qc.py` makes contact sheets for visual review.
4. `generate_embeddings.py` creates resumable OpenCLIP or DINOv2 arrays.
5. `verify_embeddings.py` checks alignment, norms, and a retrieval smoke test.

Install requirements inside a clone of the working YOLO environment:

```bash
conda create --name image_similarity --clone botany_yolo
conda activate image_similarity
python -m pip install -r requirements.txt
```

All commands are intended to be run from `/workspace/image_similarity` after
placing this directory at `/workspace/image_similarity/scripts`.

