#!/usr/bin/env python3
"""Crop illustrations from original pages using a validated crop manifest."""

from __future__ import annotations

import argparse
import concurrent.futures
import hashlib
import json
import os
import sys
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

import pandas as pd
from PIL import Image, ImageOps
try:
    from tqdm import tqdm
except ImportError:  # progress bars are optional
    def tqdm(iterable, **_: Any):
        return iterable


def arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--images-root", type=Path, required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=8)
    parser.add_argument("--quality", type=int, default=92)
    parser.add_argument("--overwrite", action="store_true")
    return parser.parse_args()


def locate_image(images_root: Path, relative: str) -> Path:
    candidate = images_root / relative
    if candidate.is_file():
        return candidate
    parts = Path(relative).parts
    if parts and parts[0] == "illustrations":
        candidate = images_root / Path(*parts[1:])
    return candidate


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def process_page(task: tuple[str, list[dict[str, Any]], str, str, int, bool]) -> list[dict[str, Any]]:
    relative, rows, images_root_text, crops_root_text, quality, overwrite = task
    images_root = Path(images_root_text)
    crops_root = Path(crops_root_text)
    source_path = locate_image(images_root, relative)
    results: list[dict[str, Any]] = []
    try:
        with Image.open(source_path) as opened:
            page = ImageOps.exif_transpose(opened).convert("RGB")
    except Exception as exc:
        return [{"row_index": row["row_index"], "crop_id": row["crop_id"], "status": "source_error", "error": str(exc)} for row in rows]

    for row in rows:
        destination = crops_root / row["crop_relative_path"]
        try:
            if not destination.exists() or overwrite:
                box = (int(row["crop_left"]), int(row["crop_top"]), int(row["crop_right"]), int(row["crop_bottom"]))
                crop = page.crop(box)
                destination.parent.mkdir(parents=True, exist_ok=True)
                temporary = destination.with_name(destination.name + f".{os.getpid()}.tmp")
                crop.save(temporary, format="JPEG", quality=quality, optimize=True, progressive=True)
                os.replace(temporary, destination)
            with Image.open(destination) as check:
                width, height = check.size
                check.verify()
            results.append({
                "row_index": row["row_index"],
                "crop_id": row["crop_id"],
                "status": "ok",
                "error": None,
                "crop_file_width": width,
                "crop_file_height": height,
                "crop_file_bytes": destination.stat().st_size,
                "crop_sha256": sha256_file(destination),
            })
        except Exception as exc:
            results.append({"row_index": row["row_index"], "crop_id": row["crop_id"], "status": "crop_error", "error": str(exc)})
    return results


def main() -> int:
    args = arguments()
    images_root = args.images_root.resolve()
    output_dir = args.output_dir.resolve()
    crops_root = output_dir / "crops"
    output_dir.mkdir(parents=True, exist_ok=True)
    frame = pd.read_parquet(args.manifest).sort_values("row_index").reset_index(drop=True)
    if frame["crop_id"].duplicated().any() or frame["row_index"].duplicated().any():
        print("ERROR: manifest contains duplicate crop_id or row_index values", file=sys.stderr)
        return 2

    groups: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in frame.to_dict(orient="records"):
        groups[str(row["source_local_relative_path"])].append(row)
    tasks = [
        (relative, rows, str(images_root), str(crops_root), args.quality, args.overwrite)
        for relative, rows in sorted(groups.items())
    ]
    results: list[dict[str, Any]] = []
    with concurrent.futures.ProcessPoolExecutor(max_workers=args.workers) as executor:
        futures = [executor.submit(process_page, task) for task in tasks]
        for future in tqdm(concurrent.futures.as_completed(futures), total=len(futures), desc="Cropping pages"):
            results.extend(future.result())

    result_frame = pd.DataFrame(results)
    merged = frame.merge(result_frame, on=["row_index", "crop_id"], how="left", validate="one_to_one")
    merged = merged.sort_values("row_index").reset_index(drop=True)
    merged.to_parquet(output_dir / "crops.parquet", index=False)
    merged.to_json(output_dir / "crops.jsonl", orient="records", lines=True, force_ascii=False)
    failures = merged[merged["status"] != "ok"]
    failures.to_json(output_dir / "crop_failures.jsonl", orient="records", lines=True, force_ascii=False)
    counts = Counter(merged["status"].fillna("missing_result"))
    summary = {
        "manifest": str(args.manifest.resolve()),
        "crop_count_expected": len(frame),
        "crop_count_ok": int(counts["ok"]),
        "crop_count_failed": int(len(frame) - counts["ok"]),
        "status_counts": dict(sorted(counts.items())),
        "jpeg_quality": args.quality,
        "total_crop_bytes": int(merged.loc[merged["status"] == "ok", "crop_file_bytes"].sum()),
    }
    (output_dir / "crop_summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2))
    return 0 if counts["ok"] == len(frame) else 2


if __name__ == "__main__":
    sys.exit(main())
