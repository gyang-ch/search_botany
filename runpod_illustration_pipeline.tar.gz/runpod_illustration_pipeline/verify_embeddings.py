#!/usr/bin/env python3
"""Verify alignment and numerical validity of two embedding outputs."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd


def arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--openclip-dir", type=Path, required=True)
    parser.add_argument("--dinov2-dir", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--query-row", type=int, default=0)
    parser.add_argument("--top-k", type=int, default=10)
    return parser.parse_args()


def inspect(directory: Path) -> tuple[np.ndarray, pd.DataFrame, dict]:
    embeddings = np.load(directory / "embeddings.npy", mmap_mode="r")
    manifest = pd.read_parquet(directory / "embedding_manifest.parquet").sort_values("row_index")
    metadata = json.loads((directory / "embedding_metadata.json").read_text(encoding="utf-8"))
    return embeddings, manifest, metadata


def neighbours(embeddings: np.ndarray, query: int, top_k: int) -> tuple[np.ndarray, np.ndarray]:
    scores = np.asarray(embeddings @ embeddings[query], dtype=np.float32)
    count = min(top_k + 1, len(scores))
    candidates = np.argpartition(-scores, count - 1)[:count]
    ordered = candidates[np.argsort(-scores[candidates])]
    ordered = ordered[ordered != query][:top_k]
    return ordered, scores[ordered]


def main() -> int:
    args = arguments()
    clip, clip_manifest, clip_metadata = inspect(args.openclip_dir.resolve())
    dino, dino_manifest, dino_metadata = inspect(args.dinov2_dir.resolve())
    problems = []
    if clip.shape[0] != len(clip_manifest) or dino.shape[0] != len(dino_manifest):
        problems.append("embedding row count does not match its manifest")
    if not clip_manifest["crop_id"].reset_index(drop=True).equals(dino_manifest["crop_id"].reset_index(drop=True)):
        problems.append("OpenCLIP and DINOv2 crop_id ordering differs")
    clip_norms = np.linalg.norm(clip, axis=1)
    dino_norms = np.linalg.norm(dino, axis=1)
    if not np.isfinite(clip).all() or not np.isfinite(dino).all():
        problems.append("non-finite embedding values")
    if not np.allclose(clip_norms, 1.0, atol=2e-4) or not np.allclose(dino_norms, 1.0, atol=2e-4):
        problems.append("embeddings are not unit-normalised")
    if not 0 <= args.query_row < len(clip_manifest):
        problems.append("query-row is outside the manifest")

    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    summary = {
        "status": "failed" if problems else "ok",
        "problems": problems,
        "row_count": len(clip_manifest),
        "openclip_shape": list(clip.shape),
        "dinov2_shape": list(dino.shape),
        "openclip_norm_range": [float(clip_norms.min()), float(clip_norms.max())],
        "dinov2_norm_range": [float(dino_norms.min()), float(dino_norms.max())],
        "openclip_model": clip_metadata.get("architecture"),
        "dinov2_model": dino_metadata.get("architecture"),
    }
    if not problems:
        clip_rows, clip_scores = neighbours(clip, args.query_row, args.top_k)
        dino_rows, dino_scores = neighbours(dino, args.query_row, args.top_k)
        query_id = str(clip_manifest.iloc[args.query_row]["crop_id"])
        result_rows = []
        for rank, (row, score) in enumerate(zip(clip_rows, clip_scores), 1):
            result_rows.append({"model": "openclip", "query_crop_id": query_id, "rank": rank, "row_index": int(row), "crop_id": clip_manifest.iloc[row]["crop_id"], "cosine_similarity": float(score), "crop_relative_path": clip_manifest.iloc[row]["crop_relative_path"]})
        for rank, (row, score) in enumerate(zip(dino_rows, dino_scores), 1):
            result_rows.append({"model": "dinov2", "query_crop_id": query_id, "rank": rank, "row_index": int(row), "crop_id": dino_manifest.iloc[row]["crop_id"], "cosine_similarity": float(score), "crop_relative_path": dino_manifest.iloc[row]["crop_relative_path"]})
        pd.DataFrame(result_rows).to_csv(output / "smoke_test_neighbours.csv", index=False)
        summary["top_k_overlap_count"] = len(set(clip_rows.tolist()) & set(dino_rows.tolist()))
        summary["query_row"] = args.query_row
        summary["query_crop_id"] = query_id
    (output / "embedding_verification.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2))
    return 2 if problems else 0


if __name__ == "__main__":
    sys.exit(main())

