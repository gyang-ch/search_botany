#!/usr/bin/env python3
"""Generate resumable L2-normalised OpenCLIP or DINOv2 embeddings."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import sys
import time
from pathlib import Path
from typing import Any, Callable

import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
from PIL import Image
from torch.utils.data import DataLoader, Dataset
from torchvision import transforms


OPENCLIP_ARCHITECTURE = "ViT-B-32"
OPENCLIP_WEIGHTS = "laion2b_s34b_b79k"
DINOV2_MODEL = "dinov2_vitb14"


def arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", choices=("openclip", "dinov2"), required=True)
    parser.add_argument("--crop-root", type=Path, required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--batch-size", type=int, default=64)
    parser.add_argument("--workers", type=int, default=8)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--restart", action="store_true", help="Discard an incomplete embedding file and restart at row zero.")
    return parser.parse_args()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


class CropDataset(Dataset):
    def __init__(self, frame: pd.DataFrame, crop_root: Path, preprocess: Callable[[Image.Image], torch.Tensor], start: int):
        self.frame = frame
        self.crop_root = crop_root
        self.preprocess = preprocess
        self.start = start

    def __len__(self) -> int:
        return len(self.frame) - self.start

    def __getitem__(self, offset: int) -> tuple[int, torch.Tensor]:
        index = self.start + offset
        path = self.crop_root / str(self.frame.iloc[index]["crop_relative_path"])
        with Image.open(path) as opened:
            image = opened.convert("RGB")
        return index, self.preprocess(image)


def load_model(name: str, device: torch.device) -> tuple[torch.nn.Module, Callable, int, dict[str, Any]]:
    if name == "openclip":
        import open_clip

        model, _, preprocess = open_clip.create_model_and_transforms(
            OPENCLIP_ARCHITECTURE, pretrained=OPENCLIP_WEIGHTS
        )
        dimension = int(model.visual.output_dim)
        metadata = {
            "family": "OpenCLIP",
            "architecture": OPENCLIP_ARCHITECTURE,
            "pretrained_weights": OPENCLIP_WEIGHTS,
            "library_version": getattr(open_clip, "__version__", "unknown"),
            "preprocessing": repr(preprocess),
        }
    else:
        model = torch.hub.load("facebookresearch/dinov2", DINOV2_MODEL)
        preprocess = transforms.Compose([
            transforms.Resize(256, interpolation=transforms.InterpolationMode.BICUBIC, antialias=True),
            transforms.CenterCrop(224),
            transforms.ToTensor(),
            transforms.Normalize(mean=(0.485, 0.456, 0.406), std=(0.229, 0.224, 0.225)),
        ])
        dimension = 768
        metadata = {
            "family": "DINOv2",
            "architecture": DINOV2_MODEL,
            "pretrained_weights": "LVD-142M official torch.hub weights",
            "preprocessing": repr(preprocess),
        }
    model = model.to(device)
    model.eval()
    return model, preprocess, dimension, metadata


def encode(model_name: str, model: torch.nn.Module, images: torch.Tensor) -> torch.Tensor:
    if model_name == "openclip":
        return model.encode_image(images)
    return model(images)


def write_progress(path: Path, value: dict[str, Any]) -> None:
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")
    os.replace(temporary, path)


def main() -> int:
    args = arguments()
    if args.device.startswith("cuda") and not torch.cuda.is_available():
        print("ERROR: CUDA requested but torch.cuda.is_available() is false", file=sys.stderr)
        return 2
    device = torch.device(args.device)
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    embedding_path = output_dir / "embeddings.npy"
    progress_path = output_dir / "progress.json"
    manifest_hash = sha256_file(args.manifest.resolve())

    frame = pd.read_parquet(args.manifest).sort_values("row_index").reset_index(drop=True)
    if len(frame) == 0 or (frame["status"] != "ok").any():
        print("ERROR: crop manifest is empty or contains failed crops", file=sys.stderr)
        return 2
    expected_indices = np.arange(len(frame), dtype=np.int64)
    if not np.array_equal(frame["row_index"].to_numpy(dtype=np.int64), expected_indices):
        print("ERROR: row_index must be contiguous from zero", file=sys.stderr)
        return 2
    if frame["crop_id"].duplicated().any():
        print("ERROR: duplicate crop_id values", file=sys.stderr)
        return 2

    model, preprocess, dimension, model_metadata = load_model(args.model, device)
    start_index = 0
    if args.restart:
        embedding_path.unlink(missing_ok=True)
        progress_path.unlink(missing_ok=True)
    elif progress_path.exists():
        progress = json.loads(progress_path.read_text(encoding="utf-8"))
        if progress.get("model") != args.model or progress.get("manifest_sha256") != manifest_hash:
            print("ERROR: existing progress belongs to another model or manifest; pass --restart", file=sys.stderr)
            return 2
        if progress.get("status") == "completed":
            print(f"Embedding run already completed: {output_dir}")
            return 0
        start_index = int(progress.get("next_index", 0))

    if embedding_path.exists():
        embeddings = np.lib.format.open_memmap(embedding_path, mode="r+")
        if embeddings.shape != (len(frame), dimension) or embeddings.dtype != np.float32:
            print("ERROR: existing embeddings.npy has an unexpected shape/dtype; pass --restart", file=sys.stderr)
            return 2
    else:
        embeddings = np.lib.format.open_memmap(
            embedding_path, mode="w+", dtype=np.float32, shape=(len(frame), dimension)
        )

    dataset = CropDataset(frame, args.crop_root.resolve(), preprocess, start_index)
    loader = DataLoader(
        dataset,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=args.workers,
        pin_memory=device.type == "cuda",
        persistent_workers=args.workers > 0,
    )
    started = time.time()
    next_index = start_index
    write_progress(progress_path, {
        "status": "running", "model": args.model, "manifest_sha256": manifest_hash,
        "next_index": start_index, "total_rows": len(frame),
    })
    try:
        with torch.inference_mode():
            for batch_number, (indices, images) in enumerate(loader, 1):
                images = images.to(device, non_blocking=True)
                with torch.autocast(device_type=device.type, dtype=torch.float16, enabled=device.type == "cuda"):
                    features = encode(args.model, model, images)
                features = F.normalize(features.float(), dim=-1)
                index_array = indices.numpy()
                embeddings[index_array] = features.cpu().numpy()
                next_index = int(index_array[-1]) + 1
                if batch_number % 25 == 0 or next_index == len(frame):
                    embeddings.flush()
                    write_progress(progress_path, {
                        "status": "running", "model": args.model,
                        "manifest_sha256": manifest_hash, "next_index": next_index,
                        "total_rows": len(frame), "elapsed_seconds": round(time.time() - started, 2),
                    })
                    print(f"{args.model}: {next_index:,}/{len(frame):,}", flush=True)
    except KeyboardInterrupt:
        embeddings.flush()
        write_progress(progress_path, {
            "status": "interrupted", "model": args.model,
            "manifest_sha256": manifest_hash, "next_index": next_index,
            "total_rows": len(frame),
        })
        print("Interrupted safely; rerun the same command to resume.", file=sys.stderr)
        return 130

    embeddings.flush()
    norms = np.linalg.norm(np.asarray(embeddings), axis=1)
    if not np.isfinite(embeddings).all() or not np.allclose(norms, 1.0, atol=2e-4):
        print("ERROR: embedding validation failed (non-finite values or invalid L2 norms)", file=sys.stderr)
        return 2
    embedding_manifest = frame[[
        "row_index", "crop_id", "source", "item_id", "page_number",
        "source_blob_name", "crop_relative_path", "confidence",
    ]].copy()
    embedding_manifest.to_parquet(output_dir / "embedding_manifest.parquet", index=False)
    embedding_manifest.to_json(output_dir / "embedding_manifest.jsonl", orient="records", lines=True, force_ascii=False)
    metadata = {
        **model_metadata,
        "shape": [len(frame), dimension],
        "dtype": "float32",
        "l2_normalized": True,
        "source_crop_manifest": str(args.manifest.resolve()),
        "source_crop_manifest_sha256": manifest_hash,
        "embedding_file_sha256": sha256_file(embedding_path),
        "torch_version": torch.__version__,
        "cuda_version": torch.version.cuda,
        "device": str(device),
        "gpu_name": torch.cuda.get_device_name(device) if device.type == "cuda" else None,
        "python_version": platform.python_version(),
        "batch_size": args.batch_size,
        "workers": args.workers,
        "elapsed_seconds_this_invocation": round(time.time() - started, 2),
    }
    (output_dir / "embedding_metadata.json").write_text(json.dumps(metadata, indent=2) + "\n", encoding="utf-8")
    write_progress(progress_path, {
        "status": "completed", "model": args.model, "manifest_sha256": manifest_hash,
        "next_index": len(frame), "total_rows": len(frame),
    })
    print(json.dumps(metadata, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())

