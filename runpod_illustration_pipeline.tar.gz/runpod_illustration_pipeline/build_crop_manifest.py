#!/usr/bin/env python3
"""Build and validate a deterministic illustration-crop manifest.

Dataset membership comes only from frozen page_log.jsonl records whose action
is ``kept_uploaded``. Azure directory contents never define membership.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import sys
from collections import Counter
from pathlib import Path
from typing import Any

import pandas as pd
from PIL import Image, ImageOps
try:
    from tqdm import tqdm
except ImportError:  # progress bars are optional
    def tqdm(iterable, **_: Any):
        return iterable


def arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--images-root", type=Path, required=True)
    parser.add_argument("--state-root", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--allow-missing", action="store_true")
    parser.add_argument("--skip-orphan-scan", action="store_true")
    return parser.parse_args()


def canonical_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def locate_image(images_root: Path, blob_name: str) -> Path:
    relative = Path(blob_name.replace("\\", "/").lstrip("/"))
    candidates = [images_root / relative]
    if relative.parts and relative.parts[0] == "illustrations":
        candidates.append(images_root / Path(*relative.parts[1:]))
    for candidate in candidates:
        if candidate.is_file():
            return candidate
    return candidates[-1]


def source_from_record(record: dict[str, Any], blob_name: str) -> str:
    source = record.get("source")
    if source:
        return "bodleian_new" if source == "bodleian" else str(source)
    parts = Path(blob_name).parts
    if len(parts) >= 2 and parts[0] == "illustrations":
        return parts[1]
    if record.get("bodleian_item_id"):
        return "bodleian_new"
    if record.get("gallica_item_id"):
        return "gallica"
    return "unknown"


def item_id_from_record(record: dict[str, Any], blob_name: str) -> str:
    for key in (
        "source_item_id", "bodleian_item_id", "gallica_item_id", "mdz_item_id",
        "ndl_item_id", "rmda_item_id", "wellcome_item_id",
    ):
        if record.get(key) is not None:
            return str(record[key])
    parts = Path(blob_name).parts
    return parts[-2] if len(parts) >= 2 else "unknown"


def scaled_box(
    detection: dict[str, Any], record: dict[str, Any], width: int, height: int
) -> tuple[float, float, float, float, str] | None:
    normalized = detection.get("bbox_normalized_xyxy")
    if isinstance(normalized, list) and len(normalized) == 4:
        try:
            values = tuple(float(v) for v in normalized)
        except (TypeError, ValueError):
            return None
        if all(math.isfinite(v) for v in values):
            x1, y1, x2, y2 = values
            return x1 * width, y1 * height, x2 * width, y2 * height, "normalized"

    pixels = detection.get("bbox_xyxy")
    if not isinstance(pixels, list) or len(pixels) != 4:
        return None
    try:
        x1, y1, x2, y2 = (float(v) for v in pixels)
    except (TypeError, ValueError):
        return None
    if not all(math.isfinite(v) for v in (x1, y1, x2, y2)):
        return None
    logged_width = record.get("downloaded_width")
    logged_height = record.get("downloaded_height")
    if isinstance(logged_width, (int, float)) and logged_width > 0:
        x1, x2 = x1 * width / logged_width, x2 * width / logged_width
    if isinstance(logged_height, (int, float)) and logged_height > 0:
        y1, y2 = y1 * height / logged_height, y2 * height / logged_height
    return x1, y1, x2, y2, "pixel"


def clamp_box(values: tuple[float, float, float, float], width: int, height: int) -> tuple[int, int, int, int] | None:
    x1, y1, x2, y2 = values
    left = max(0, min(width, math.floor(min(x1, x2))))
    top = max(0, min(height, math.floor(min(y1, y2))))
    right = max(0, min(width, math.ceil(max(x1, x2))))
    bottom = max(0, min(height, math.ceil(max(y1, y2))))
    if right <= left or bottom <= top:
        return None
    return left, top, right, bottom


def main() -> int:
    args = arguments()
    images_root = args.images_root.resolve()
    state_root = args.state_root.resolve()
    output_dir = args.output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    log_paths = sorted(state_root.rglob("page_log.jsonl"))
    if len(log_paths) != 6:
        print(f"ERROR: expected 6 page logs below {state_root}, found {len(log_paths)}", file=sys.stderr)
        for path in log_paths:
            print(f"  {path}", file=sys.stderr)
        return 2

    page_records: dict[str, tuple[dict[str, Any], Path, int]] = {}
    duplicate_identical = 0
    conflicting: list[str] = []
    action_counts: Counter[str] = Counter()
    for log_path in log_paths:
        with log_path.open(encoding="utf-8") as handle:
            for line_number, line in enumerate(handle, 1):
                try:
                    record = json.loads(line)
                except json.JSONDecodeError as exc:
                    print(f"ERROR: malformed JSON at {log_path}:{line_number}: {exc}", file=sys.stderr)
                    return 2
                action_counts[str(record.get("action", "missing"))] += 1
                if record.get("action") != "kept_uploaded" or not record.get("blob_name"):
                    continue
                blob_name = str(record["blob_name"]).replace("\\", "/").lstrip("/")
                previous = page_records.get(blob_name)
                if previous:
                    if canonical_json(previous[0]) == canonical_json(record):
                        duplicate_identical += 1
                    else:
                        conflicting.append(blob_name)
                    continue
                page_records[blob_name] = (record, log_path, line_number)

    missing: list[str] = []
    unreadable: list[str] = []
    invalid_boxes: list[dict[str, Any]] = []
    rows: list[dict[str, Any]] = []
    referenced_local_paths: set[str] = set()
    source_counts: Counter[str] = Counter()

    for blob_name in tqdm(sorted(page_records), desc="Validating retained pages"):
        record, log_path, line_number = page_records[blob_name]
        image_path = locate_image(images_root, blob_name)
        if not image_path.is_file():
            missing.append(blob_name)
            continue
        try:
            with Image.open(image_path) as opened:
                transposed = ImageOps.exif_transpose(opened)
                width, height = transposed.size
                transposed.verify()
        except Exception as exc:
            unreadable.append(f"{blob_name}\t{exc}")
            continue
        local_relative = image_path.relative_to(images_root).as_posix()
        referenced_local_paths.add(local_relative)
        source = source_from_record(record, blob_name)
        item_id = item_id_from_record(record, blob_name)
        page_name = Path(blob_name).stem
        illustration_number = 0
        for detection_index, detection in enumerate(record.get("detected_classes") or []):
            if str(detection.get("class", "")).casefold() != "illustration":
                continue
            box_data = scaled_box(detection, record, width, height)
            if box_data is None:
                invalid_boxes.append({"blob_name": blob_name, "detection_index": detection_index, "reason": "missing_or_invalid_coordinates"})
                continue
            x1, y1, x2, y2, coordinate_source = box_data
            crop_box = clamp_box((x1, y1, x2, y2), width, height)
            if crop_box is None:
                invalid_boxes.append({"blob_name": blob_name, "detection_index": detection_index, "reason": "zero_area_after_clamp"})
                continue
            left, top, right, bottom = crop_box
            identity = f"{blob_name}|{detection_index}|{left},{top},{right},{bottom}"
            crop_id = hashlib.sha1(identity.encode("utf-8")).hexdigest()[:20]
            crop_relative = f"{source}/{item_id}/{page_name}__illustration_{illustration_number:03d}__{crop_id}.jpg"
            normalized = detection.get("bbox_normalized_xyxy")
            pixel = detection.get("bbox_xyxy")
            rows.append({
                "row_index": -1,
                "crop_id": crop_id,
                "source": source,
                "item_id": item_id,
                "page_number": record.get("page_number"),
                "page_index": record.get("page_index"),
                "source_blob_name": blob_name,
                "source_local_relative_path": local_relative,
                "source_image_url": record.get("image_url"),
                "state_log": log_path.relative_to(state_root).as_posix(),
                "state_log_line": line_number,
                "detection_index": detection_index,
                "illustration_number_on_page": illustration_number,
                "confidence": float(detection.get("confidence")) if detection.get("confidence") is not None else None,
                "coordinate_source": coordinate_source,
                "logged_bbox_xyxy": canonical_json(pixel) if pixel is not None else None,
                "logged_bbox_normalized_xyxy": canonical_json(normalized) if normalized is not None else None,
                "crop_left": left,
                "crop_top": top,
                "crop_right": right,
                "crop_bottom": bottom,
                "page_width": width,
                "page_height": height,
                "crop_width": right - left,
                "crop_height": bottom - top,
                "crop_relative_path": crop_relative,
                "detection_provenance": "runpod_frozen_page_log",
            })
            illustration_number += 1
            source_counts[source] += 1

    rows.sort(key=lambda row: (row["source_blob_name"], row["detection_index"], row["crop_id"]))
    for index, row in enumerate(rows):
        row["row_index"] = index

    orphans: list[str] = []
    if not args.skip_orphan_scan:
        for path in tqdm(sorted(images_root.rglob("*.jpg")), desc="Finding unreferenced images"):
            relative = path.relative_to(images_root).as_posix()
            if relative not in referenced_local_paths:
                # Account for roots both above and at the illustrations directory.
                alternate = f"illustrations/{relative}"
                if alternate not in page_records:
                    orphans.append(relative)

    dataframe = pd.DataFrame(rows)
    parquet_path = output_dir / "crop_manifest.parquet"
    jsonl_path = output_dir / "crop_manifest.jsonl"
    dataframe.to_parquet(parquet_path, index=False)
    with jsonl_path.open("w", encoding="utf-8") as handle:
        for row in rows:
            handle.write(canonical_json(row) + "\n")

    (output_dir / "missing_images.txt").write_text("\n".join(missing) + ("\n" if missing else ""), encoding="utf-8")
    (output_dir / "unreadable_images.txt").write_text("\n".join(unreadable) + ("\n" if unreadable else ""), encoding="utf-8")
    (output_dir / "orphan_images.txt").write_text("\n".join(orphans) + ("\n" if orphans else ""), encoding="utf-8")
    with (output_dir / "invalid_boxes.jsonl").open("w", encoding="utf-8") as handle:
        for value in invalid_boxes:
            handle.write(canonical_json(value) + "\n")
    (output_dir / "conflicting_page_records.txt").write_text("\n".join(conflicting) + ("\n" if conflicting else ""), encoding="utf-8")

    summary = {
        "state_root": str(state_root),
        "images_root": str(images_root),
        "page_log_count": len(log_paths),
        "action_counts": dict(sorted(action_counts.items())),
        "unique_kept_uploaded_pages": len(page_records),
        "valid_illustration_crops": len(rows),
        "crops_by_source": dict(sorted(source_counts.items())),
        "missing_referenced_images": len(missing),
        "unreadable_referenced_images": len(unreadable),
        "invalid_illustration_boxes": len(invalid_boxes),
        "unreferenced_jpg_images": len(orphans),
        "identical_duplicate_page_records": duplicate_identical,
        "conflicting_duplicate_page_records": len(conflicting),
        "manifest_jsonl_sha256": sha256_file(jsonl_path),
    }
    (output_dir / "inventory_summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2, ensure_ascii=False))
    blockers = len(missing) + len(unreadable) + len(invalid_boxes) + len(conflicting)
    if blockers and not args.allow_missing:
        print("ERROR: inventory has blockers; inspect the report files before cropping.", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
